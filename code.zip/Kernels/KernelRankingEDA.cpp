//
//  KernelRankingEDA.cpp
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 16/01/15.
//  Copyright (c) 2015 Josu Ceberio Uribe. All rights reserved.
//

#include "KernelRankingEDA.h"
#include <stdlib.h>
#include <limits>
#include <valarray>
#include <stdio.h>
#include <cmath>
#include "string.h"
#include <iomanip>
#include <gmp.h>
#include <random>
#include "LR.h"
#include "VNS.h"
/*
 * The constructor.
 */
KernelRankingEDA::KernelRankingEDA(PFSP * problem, int problem_size, long int max_evaluations, int pop_size, double sel_size, double theta, int max_restarts, int restart_countdown, int restart_shake_power)
{
    //1. Parameter settings
    m_problem=problem;
    m_problem_size=problem_size;
    m_max_evaluations=max_evaluations;
    m_evaluations=0;
    m_convergence_evaluations=0;
    m_max_restarts=max_restarts;
    m_restart_countdown=restart_countdown;
    
    m_restart_shake_power= restart_shake_power;
   
    //POPSIZE  AND SELSIZE
    m_pop_size=pop_size;
    m_sel_size=m_pop_size*0.1;
    if (m_pop_size<m_sel_size)
        m_sel_size=m_pop_size;
    
    
    //THETA PARAMETER INITIALIZATION
    if (theta==-1)
        m_theta_parameter=GetTheta_Cayley9(m_problem->m_jobs);
    else
        m_theta_parameter=theta;
    
    m_offspring_size= m_pop_size-1;
    m_kernel_num=m_sel_size;
    
    //2. initialize the population
    PopulationInitialization(m_pop_size, m_offspring_size);

    //4. Kernels initialization
    Cayley_DataStructure_Initialization();
    for (int i=0;i<m_kernel_num;i++){
        m_models.push_back(new Cayley_Model(m_problem_size, m_sel_size));
    }
    
    //5. Generate auxiliary structures for the sampling
    m_acum_ratios= new float[m_sel_size];
    m_samples_from_each_kernel=new int[m_kernel_num];

    float ratio=((float)1/(float)m_kernel_num);
    m_acum_ratios[0]=ratio;
    for (int i=1;i<m_kernel_num;i++)
        m_acum_ratios[i]=ratio+m_acum_ratios[i-1];
    m_acum_ratios[m_kernel_num-1]=1;// para redondear.

}


/*
 * Calculates the probability of sampling permutations to different distances under the Mallows model with the Cayley distance.
 */
void KernelRankingEDA::Cayley_DataStructure_Initialization(){
    
    //Calculate for the current problem size the number of permutations at each distance.
    Initialize_StirlingMatrix();
    
    gmp_acumul= new mpf_t[m_problem_size];
    for (int i=0;i<m_problem_size;i++){
        mpf_init(gmp_acumul[i]);
    }
    
    //calculate the probability of sampling a permutation at each distance.
    mpf_t prov, prov2;
    mpf_init(prov);
    mpf_init(prov2);
    for(int dista = 1 ; dista < m_problem_size ; dista++){
        mpf_set_d(prov2,(long double)exp(-m_theta_parameter  * dista));
        mpf_set_z(prov,gmp_count_matrix[m_problem_size][m_problem_size-dista]);
        mpf_mul(prov,prov,prov2);
        mpf_add(gmp_acumul[dista],gmp_acumul[dista-1],prov);
    }
    mpf_clear(prov2);
    mpf_clear(prov);
    
    double * m_probabilities= new double[m_problem_size];
    for (int i=0;i<m_problem_size;i++){
        mpf_div(gmp_acumul[i],gmp_acumul[i],gmp_acumul[m_problem_size-1]);
        m_probabilities[i]=mpf_get_d(gmp_acumul[i]);
    }
    
    for (int i=m_problem_size-1;i>0;i--){
        m_probabilities_list.push_front(m_probabilities[i]-m_probabilities[i-1]);
    }
    m_probabilities_list.push_front(m_probabilities[0]);
    delete [] m_probabilities;
}
/*
 * Initializes the population of the EDA.
 */
void KernelRankingEDA::PopulationInitialization(int pop_size, int off_size){
    m_population= new CPopulation(pop_size, off_size,m_problem_size);
    int * genes= new int[m_problem_size];
    
#ifndef LR
    for(int i=0;i<pop_size;i++)
    {
        //Create random individual
        GenerateRandomPermutation(genes,m_problem_size);
        m_population->SetToPopulation(genes, i, m_problem->EvaluateInv(genes));
        m_evaluations++;
    }
#else
    CIndividual * lr_individual=NonDeterministic_LRnm(m_problem_size,m_problem);
    lr_individual->SetValue(m_problem->EvaluateInv(lr_individual->Genes()));
#ifdef PRINT_LOG
    cout<<"LR solution: "<<lr_individual<<endl;
#endif
    CIndividual * ind;
    int i,j;
    //guided from the solution of LR
    for (i=0;i<pop_size/2;i++)
    {
        ind= lr_individual->Clone();
        ind-> Shake_Insert(m_problem_size/10);

        m_population->SetToPopulation(ind->Genes(), i, m_problem->EvaluateInv(ind->Genes()));
        m_evaluations++;
        
        delete ind;
    }
    //random initialization
    for(j=i;j<pop_size;j++)
    {
        //Create random individual
        GenerateRandomPermutation(genes,m_problem_size);
        m_population->SetToPopulation(genes, j, m_problem->EvaluateInv(genes));
        m_evaluations++;
    }
    delete lr_individual;
#endif
    delete [] genes;
    m_population->SortPopulation(0);
    m_best=m_population->m_individuals[0]->Clone();
 
}

/*
 * The destructor. It frees the memory allocated..
 */
KernelRankingEDA::~KernelRankingEDA()
{
    delete m_best;
    delete m_population;
    delete [] m_acum_ratios;
    delete [] m_samples_from_each_kernel;
    m_models.clear();
    
    int i,j;

    for (i=0;i<m_problem_size+1;i++){
        mpz_clear(gmp_factorials[i]);

        for ( j=0;j<m_problem_size+1;j++){
            mpz_clear(gmp_count_matrix[i][j]);
        }
    }
    for (i=0;i<m_problem_size;i++)
        mpf_clear(gmp_acumul[i]);
    
}


/*
 * Initializes the stirling matrix numbers for the sampling of Kernels of Mallows-Cayley models.
 */
void KernelRankingEDA::Initialize_StirlingMatrix(){
    int i,j;
    gmp_count_matrix= new mpz_t*[m_problem_size+1];
    gmp_factorials = new mpz_t[m_problem_size+1];
    for (i=0;i<m_problem_size+1;i++)
        mpz_init(gmp_factorials[i]);

    for (i = 0 ; i < m_problem_size+1; i ++ ){
        gmp_count_matrix [ i ] = new mpz_t [m_problem_size+1];
        for(j= 0;j<m_problem_size+1;j++){
            mpz_init(gmp_count_matrix[ i ][ j ]);
            mpz_set_si(gmp_count_matrix[i][j],-1);
        }
        if(i != 0)
            mpz_mul_si(gmp_factorials[i],gmp_factorials[i-1],i);
        else
            mpz_set_si(gmp_factorials[0],1);
    }

    mpz_set_si(gmp_count_matrix[0][0],1);

    for (i = 0 ; i <= m_problem_size; i ++){
        mpz_set_si(gmp_count_matrix[i][i],1);
        mpz_set_si(gmp_count_matrix[i][0],0);
        if ( i > 0 )
            mpz_set(gmp_count_matrix[i][1],gmp_factorials[i-1]);
    }

    mpz_t prov;
    mpz_init(prov);
    for (i = 2 ; i <= m_problem_size; i ++){
        for (j = 2 ; j < i ; j++){
            mpz_mul_si(prov,gmp_count_matrix[i-1][j],i-1);
            mpz_add(gmp_count_matrix[i][j],gmp_count_matrix[i-1][j-1],prov);
        }
    }
    mpz_clear(prov);
}

/*
 * Running function
 */
double KernelRankingEDA::Run(){
    
    //variable initializations.
    double newScore;
    int iterations=0;
    int restarts=0;
    double best_fitness=m_best->Value();
    std::discrete_distribution<> distance_sampler(m_probabilities_list.begin(), m_probabilities_list.end());
    std::mt19937 gen(m_rd());
    #ifdef PRINT_LOG
    cout<<"BEST_FIT, AVG_FIT_POP , AVG_DIST_POP , EVALS, EVALS_REMAINING, THETA"<<endl;
    #endif
    
#ifdef RESTART
    int count_down_for_restart=m_restart_countdown;
    double previous_iteration_best=INT_MAX;

#endif
    //EDA iteration. Stopping criterion is the maximum number of evaluations performed
    while (m_evaluations<m_max_evaluations){
        //cout<<"Iteration: "<<iterations<<endl;
#ifndef MAX_SSP
        //learn
        Learn(m_population);
#else
        if (iterations!=0)
            Learn_MaxSSP(m_population);
        else
            Learn(m_population);
#endif
        
       // cout<<"sampling..."<<endl;
       if ((m_evaluations+m_offspring_size)<m_max_evaluations){
            m_evaluations+= Sample(m_population,&distance_sampler,&gen,m_offspring_size,m_problem);
        }
        else{
            m_evaluations+= Sample(m_population,&distance_sampler,&gen,(int)(m_max_evaluations-m_evaluations),m_problem);
        }
     
       // cout<<"sorting..."<<endl;
        //sort the population.
        m_population->SortPopulation(1);
        

        //update indicators
        for (int i=0;i<m_pop_size;i++)
            m_population->m_individuals[i]->IncreaseGeneration();
       
        
        newScore=m_population->m_individuals[0]->Value();
        
        if (newScore<best_fitness)
        {

            m_convergence_evaluations=m_evaluations;
            best_fitness=newScore;
            m_best->SetParameters(m_population->m_individuals[0]->Genes(), newScore);

#ifdef PRINT_LOG
            cout<<m_best->Value()<<", "<<m_population->m_individuals[0]->Value()
          //  <<", "<<m_population->AverageDistancePopulation(m_sel_size)
            <<" , "<<m_evaluations<<" , "<<m_max_evaluations-m_evaluations<<", "<<m_theta_parameter
#ifdef RESTART
            <<","<<count_down_for_restart
#endif
            <<endl;
            
#endif

#ifdef RESTART
             count_down_for_restart=m_restart_countdown;
            previous_iteration_best=newScore;
#endif
        }
#ifdef RESTART
        else if (newScore<previous_iteration_best){

#ifdef PRINT_LOG
            cout<<m_best->Value()<<", "<<m_population->m_individuals[0]->Value()
            //<<" , "<<m_population->AverageDistancePopulation(m_sel_size)
            <<" , "<<m_evaluations<<" , "<<m_max_evaluations-m_evaluations<<", "<<m_theta_parameter
            <<","<<count_down_for_restart
            <<endl;
#endif
            count_down_for_restart=m_restart_countdown;
            previous_iteration_best=newScore;

        }
        else{
            
            if (count_down_for_restart==0){

                if (restarts==m_max_restarts){
                    return best_fitness;
                }
                m_evaluations+=m_population->Restart(m_best,m_problem, m_restart_shake_power);
                restarts++;
#ifdef PRINT_LOG
                cout<<"RESTART "<<restarts<<endl;
#endif
                count_down_for_restart=m_restart_countdown;
   
                //sort the population.
                m_population->SortPopulation(1);
                previous_iteration_best=INT_MAX;
            }
            else{
                count_down_for_restart--;
            }
        }
#endif
       

        iterations++;
    }
    return best_fitness;
}


/*
 * Learns the kernels selecting them following the maximum spread subset problem.
 */
void KernelRankingEDA::Learn_MaxSSP(CPopulation * population){
    
    int i,j, index_pos, dist,max_dist;

    //Initialize lists
    m_selected.push_back(0);
    for (i=1;i<m_pop_size;i++)
        m_not_selected.push_back(i);
    
    // Find the set of solutions that maximizes the spread sub-set problem.
    for (i=1;i<m_kernel_num;i++){
//      index_pos=SolutionToMaxDistanceToSelected(m_selected, m_not_selected);
        index_pos=0;
        max_dist=0;
        for (j=0;j<m_not_selected.size();j++)
        {
            dist=HammingDistance(m_population->m_individuals[m_not_selected[j]]->Genes(),m_population->m_individuals[m_selected[m_selected.size()-1]]->Genes());
            if (max_dist<dist){
                max_dist=dist;
                index_pos=j;
            }
        }
        m_selected.push_back(m_not_selected[index_pos]);
        m_not_selected.erase(m_not_selected.begin()+index_pos);
    }
    
    //initialize iterators aand auxiliary variables
    m_iterator=m_models.begin();
    m_iterator_last=m_models.end();

    for (i=0;i<m_kernel_num;i++){

        //move container of the linked list
        m_models.splice(m_iterator,m_models,m_iterator_last,m_iterator_last);
        
        //set data to the kernel.
        (*m_iterator)->Learn(population->m_individuals[m_selected[i]], m_theta_parameter);

        //update iterators
        m_iterator_last=m_models.end();

        m_iterator++;
    }
    m_selected.clear();
    m_not_selected.clear();
}

/*
 * Learns the kernels of the specified model by means.
 */
void KernelRankingEDA::Learn(CPopulation * population){

    
    //initialize iterators aand auxiliary variables
    m_iterator=m_models.begin();
    m_iterator_last=m_models.end();
    
    for (int i=0;i<m_kernel_num;i++){
        
        //move container of the linked list
        m_models.splice(m_iterator,m_models,m_iterator_last,m_iterator_last);
        
        //set data to the kernel.
        (*m_iterator)->Learn(population->m_individuals[i], m_theta_parameter);
        
        //update iterators
        m_iterator_last=m_models.end();
        
        m_iterator++;
    }
}

/*
 * Sample the Kernels.
 */
int KernelRankingEDA::Sample(CPopulation * population, std::discrete_distribution<> * distance_sampler,std::mt19937 * gen, int num_samples, PFSP * problem)
{

    //1.- Calculate with Stochastic Universal Sampling the number of individuals to sample from each model
    int i,g;
    std::fill_n(m_samples_from_each_kernel,m_kernel_num,0);
    double ratio=(double)1/(double)num_samples;
    double acum=((double)rand()/((double)RAND_MAX +1)) * ratio;
    i=0; g=0;
    while (i<num_samples){
        if (acum>1)
            acum=1;
        if (acum<=m_acum_ratios[g]){
            m_samples_from_each_kernel[g]++;
            acum+=ratio;
            i++;
        }
        else{
            g++;
        }
    }
    
    //2. Perform the sampling step.
    i=0;
    int index_at_population=0;
    int sampled_solutions=0;
    for (m_iterator=m_models.begin(); m_iterator!=m_models.end();m_iterator++){
        sampled_solutions+=(*m_iterator)->Sampling(distance_sampler,gen, gmp_count_matrix, population, m_samples_from_each_kernel[i], &index_at_population, problem);
        i++;
    }

    return sampled_solutions;
}

/*
 * Returns the number of performed evaluations.
 */
long int KernelRankingEDA::GetPerformedEvaluations(){
    return m_convergence_evaluations;
}

/*
 * Returns the fitness of the best solution obtained.
 */
double KernelRankingEDA::GetBestSolutionFitness(){
    return m_best->Value();
}

/*
 * Returns the best solution obtained.
 */
CIndividual * KernelRankingEDA::GetBestSolution(){
    return m_best;
}

/*
 * Returns the theta value that P(\sigma_0)=0.9 with the Mallows model under the Cayley distance for the specified problem size.
 */
double KernelRankingEDA::GetTheta_Cayley9(int problem_size){
    double upper;
    switch (problem_size) {
        case 10:
            upper=6.1;
            break;
        case 20:
            upper=7.5;
            break;
        case 30:
            upper=8.4;
            break;
        case 40:
            upper=8.9;
            break;
        case 50:
            upper=9.4;
            break;
        case 60:
            upper=9.8;
            break;
        case 70:
            upper=10.1;
            break;
        case 80:
            upper=10.3;
            break;
        case 90:
            upper=10.6;
            break;
        case 100:
            upper=10.8;
            break;
        case 150:
            upper=11.6;
            break;
        case 200:
            upper=12.2;
            break;
        case 250:
            upper=12.6;
            break;
        case 300:
            upper=13;
            break;
        case 350:
            upper=13.3;
            break;
        case 400:
            upper=13.6;
            break;
        case 450:
            upper=13.8;
            break;
        case 500:
            upper=14;
            break;
        default:
            upper=14;
            break;
    }
    return upper;
}

/*
 * Returns the theta value that P(\sigma_0)=0.8 with the Mallows model under the Cayley distance for the specified problem size.
 */
double KernelRankingEDA::GetTheta_Cayley8(int problem_size){
    double upper;
    switch (problem_size) {
        case 10:
            upper=5.31;
            break;
        case 20:
            upper=6.7;
            break;
        case 30:
            upper=7.6;
            break;
        case 40:
            upper=8.2;
            break;
        case 50:
            upper=8.6;
            break;
        case 60:
            upper=9.0;
            break;
        case 70:
            upper=9.3;
            break;
        case 80:
            upper=9.6;
            break;
        case 90:
            upper=9.8;
            break;
        case 100:
            upper=10;
            break;
        case 150:
            upper=10.8;
            break;
        case 200:
            upper=11.4;
            break;
        case 250:
            upper=11.8;
            break;
        case 300:
            upper=12.2;
            break;
        case 350:
            upper=12.5;
            break;
        case 400:
            upper=12.8;
            break;
        case 450:
            upper=13.01;
            break;
        case 500:
            upper=13.2;
            break;
        default:
            upper=13.2;
            break;
    }
    return upper;
}


/*
 * Calculates the Hamming distance between 2 permutations.
 */
int KernelRankingEDA::HammingDistance(int* permutationA, int*permutationB)
{
    int dist=0;
    for(int i=0; i<m_problem_size; i++){
        dist+=(permutationA[i]!=permutationB[i]);
    }
    return dist;
}
