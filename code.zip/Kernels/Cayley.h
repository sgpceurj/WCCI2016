/*
 *  Cayley.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/18/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#ifndef __CAYLEY_MODEL_H__
#define __CAYLEY_MODEL_H__

#define ALF 1.0e-4
#define TOLX 1.0e-7
#define MAXITS 200
#define EPS 1.0e-4
#define TOLF 1.0e-4
#define TOLMIN 1.0e-6
#define STPMX 100.0
#include <cmath>
#include <iostream>
#include <math.h>
#include "PFSP.h"
#include "Population.h"
#include <gmp.h>
#include <random>

#define FREERETURN {free_matrix(fjac,1,n,1,n);free_vector(fvec,1,n);\
free_vector(p,1,n);free_ivector(indx,1,n);return;}

class Cayley_Model
{
public:

    /*
     * Problem size.
     */
    int m_problem_size;

    /*
     * Sample size.
     */
    int m_sample_size;
    
    /*
     * Spread parameters vector.
     */
    double m_theta_parameter;
    
    /*
     * The whole individual
     */
    CIndividual * m_individual;

	/*
	 * The constructor.
	 */
	Cayley_Model(int problem_size, int sel_size);
	
	/*
	 * The destructor. It frees the memory allocated at the construction of the Cayley model.
	 */
	virtual ~Cayley_Model();
    
    /*
     * Builds the Mallows model for the Cayley distance with the given CR and theta parameters.
     */
    bool Learn(CIndividual * individual, double theta);


    /*
     * Given the consensus ranking, it samples a new individual based on the stirling numbers, with big numbers.
     */
    int Sampling(std::discrete_distribution<> * distance_sampler,std::mt19937 * gen, mpz_t ** stirling_matrix, CPopulation * population, int num_samples, int * index_at_population, PFSP * problem);
    
private:
   
    /*
     * The auxiliary vector for sampling solutions.
     */
    int * m_sampling_permutation;
    
    /*
     * Auxiliary vector for the x.
     */
    int * m_aux;

    /*
     * Auxiliary vector for the stirling sampling type.
     */
    bool * m_long_cycle;
    int * m_sigma_inv;
    
    /*
     * Generates a random permutation of the given size
     */
    void generate_random_permutation(int len, int*sigma);
    
    /*
     * Generates a permutation with the given number of cycles.
     */
    void generate_permu_with_k_cycles(int n, int k, int * sigma, mpz_t ** stirling_matrix);

    
};

#endif

