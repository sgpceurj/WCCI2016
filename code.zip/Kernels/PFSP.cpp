/*
 *  PFSP.cpp
 *  CompetitionWCCI2014
 *
 *  Created by Josu Ceberio Uribe on 7/11/13.
 *  Copyright 2013 University of the Basque Country. All rights reserved.
 *
 */

#include "PFSP.h"
#include "Tools.h"
#include "Variables.h"
#include <stdlib.h>
/*
 *Class constructor.
 */
PFSP::PFSP()
{

}

/*
 * Class destructor.
 */
PFSP::~PFSP()
{
	for	(int i=0;i<m_machines;i++)
		delete [] m_processingtimes[i];
	delete [] m_processingtimes;
    delete [] m_timeTable;
    delete [] m_aux;
}

/*
 * Evaluates inverted solution of the given solution with the total flow time criterion.
 */
double PFSP::EvaluateInv(int * genes)
{
    Invert(genes,m_jobs,m_aux);
    
    std::fill_n(m_timeTable,m_machines,0);
//    for (int i=0;i<m_machines;i++) m_timeTable[i]=0;
	int j,z, job, machine;
    int prev_machine;

	int first_gene=m_aux[0];
    m_timeTable[0]=m_processingtimes[0][first_gene];
	for (j=1;j<m_machines;j++)
	{
		m_timeTable[j]=m_timeTable[j-1]+m_processingtimes[j][first_gene];
	}
	
	double fitness=m_timeTable[m_machines-1];
	for (z=1;z<m_jobs;z++)
	{
		job=m_aux[z];
		
		//machine 0 is always incremental, so:
		m_timeTable[0]+=m_processingtimes[0][job];
		prev_machine=m_timeTable[0];
		for (machine=1;machine<m_machines;machine++)
		{
			m_timeTable[machine]= MAX(prev_machine,m_timeTable[machine])+ m_processingtimes[machine][job];
			prev_machine=m_timeTable[machine];
		}
		
		fitness+=m_timeTable[m_machines-1];
	}
	
	return fitness;
}

/*
 * Evaluates the given solution with the total flow time criterion.
 */
double PFSP::Evaluate(int * genes)
{
    for (int i=0;i<m_machines;i++) m_timeTable[i]=0;
	int j,z, job, machine;
    int prev_machine;
    
	int first_gene=genes[0];
    m_timeTable[0]=m_processingtimes[0][first_gene];
	for (j=1;j<m_machines;j++)
	{
		m_timeTable[j]=m_timeTable[j-1]+m_processingtimes[j][first_gene];
	}
	
	double fitness=m_timeTable[m_machines-1];
	for (z=1;z<m_jobs;z++)
	{
		job=genes[z];
		
		//machine 0 is always incremental, so:
		m_timeTable[0]+=m_processingtimes[0][job];
		prev_machine=m_timeTable[0];
		for (machine=1;machine<m_machines;machine++)
		{
			m_timeTable[machine]= MAX(prev_machine,m_timeTable[machine])+ m_processingtimes[machine][job];
			prev_machine=m_timeTable[machine];
		}
		
		fitness+=m_timeTable[m_machines-1];
	}

	return fitness;
}

int PFSP::Read(string filename)
{
	bool readMatrix=false;
	bool readDimension=false;

	char line[2048]; // variable for input value
	string data="";
	ifstream indata;
	indata.open(filename.c_str(),ios::in);
	while (!indata.eof())
	{
		//process lines
		indata.getline(line, 2048);
		stringstream ss;
		string sline;
		ss << line;
		ss >> sline;
        //cout<<"sline: "<<sline<<endl;
		if (strContains(line,"number of jobs")==true && readMatrix==true)
		{
			break;
		}
		else if (strContains(line,"number of jobs")==true)
		{
			readDimension=true;
		}
		else if (readDimension==true)
		{
			m_jobs = atoi(strtok (line," "));
			//cout<<"JOB NUM: "<<m_jobs<<endl;
			m_machines = atoi(strtok (NULL, " "));
			//cout<<"MACHINE NUM: "<<m_machines<<endl;
			readDimension=false;
			
		}
		else if (readMatrix)
		{;
			if (data=="")
				data = line;
			else
				data = data+' '+line;
		}
		else if (strContains(line,"processing times :"))
		{
			readMatrix=true;
		}
	}
	indata.close();
	
	//BUILD JOB PROCESSING MATRIX
	//cout << "--> BUILDING JOB PROCESSING MATRIX" << endl;
	m_processingtimes = new int*[m_machines];
	for (int i=0;i<m_machines;i++)
	{
		m_processingtimes[i]= new int[m_jobs];
	}
	m_timeTable= new int[m_machines];
	m_aux= new int[m_jobs];
	//FILL JOB PROCESSING MATRIX
	//cout << "--> FILLING JOB PROCESSING MATRIX: "<<data << endl;
	istringstream iss(data);
	int i=0;
	int j=0;
	do
	{
		string sub;
	    iss >> sub;
	    if (sub!="")
	    {
			//save distance in distances matrix. Save negative distance in order to minimize fitness instead of
			//maximize.
	    	m_processingtimes[i][j]= atoi(sub.c_str());
	    	if (j==m_jobs-1)
	    	{
	    		i++;
	    		j=0;
	    	}
	    	else
	    	{
	    		j++;
	    	}
	    }
	    else
	    {
	    	break;
	    }
	} while (iss);
	
	return (m_jobs);
}


/*
 * Returns the size of the problem.
 */
int PFSP::GetProblemSize()
{
    return m_jobs;
}

void  PFSP:: IdleTimesAtPosition(int * sequence, int size, int job_i, int * idleTimes)
{
    //cout<<"In Idle times at position, pfsp.o"<<endl;
    int timeTable[m_machines];
    int job,j,z,machine,processingTime;
    
    int first_gene=sequence[0];
    timeTable[0]=m_processingtimes[0][first_gene];
    for (j=1;j<m_machines;j++)
    {
        timeTable[j]=timeTable[j-1]+m_processingtimes[j][first_gene];
    }
    //PrintArray(sequence,size,"sequence: ");
    
    int fitness=timeTable[m_machines-1];
    for (z=1;z<size;z++)
    {
        job=sequence[z];
        
        //machine 0 is always incremental, so:
        timeTable[0]+=m_processingtimes[0][job];
        
        for (machine=1;machine<m_machines;machine++)
        {
            processingTime=m_processingtimes[machine][job];
            
            if (timeTable[machine-1]<timeTable[machine])
            {
                timeTable[machine]+=processingTime;
            }
            else
            {
                timeTable[machine]= timeTable[machine-1]+processingTime;
            }
        }
        
        fitness+=timeTable[m_machines-1];
    }
    
    //machine 0 is always incremental, so: increment job j
    timeTable[0]=timeTable[0]+m_processingtimes[0][job_i];
    
    for (machine=1;machine<m_machines;machine++)
    {
        processingTime=m_processingtimes[machine][job_i];
        
        if (timeTable[machine-1]<timeTable[machine])
        {
            timeTable[machine]=timeTable[machine]+processingTime;
        }
        else
        {
            //machine idle time occurs
            idleTimes[machine-1]=timeTable[machine-1] - timeTable[machine];
            //cout<<"idle time: "<<idleTimes[machine-1]<<" machine-1: "<<timeTable[machine-1]<<" machine: "<<timeTable[machine]<<endl;
            timeTable[machine]= timeTable[machine-1]+processingTime;
            
        }
    }
    fitness+=timeTable[m_machines-1];
}

/*
 * Partial evaluation method for LR constructive heuristic method. The call to this method is expected in the index function.
 */
int PFSP::PartialEvaluation(int * genes, int size, int * new_job_times)
{
    int timeTable[m_machines];
    int j,z, job,processingTime;
    int machine;
    int fitness=0;
    for (int i=0;i<m_machines;i++)	timeTable[i]=0;
    
    if (size!=0)
    {
        
        int first_gene=genes[0];
        timeTable[0]=m_processingtimes[0][first_gene];
        for (j=1;j<m_machines;j++)
        {
            timeTable[j]=timeTable[j-1]+m_processingtimes[j][first_gene];
        }
        
        fitness=timeTable[m_machines-1];
        
        for (z=1;z<size;z++)
        {
            
            job=genes[z];
            
            //machine 0 is always incremental, so:
            timeTable[0]+=m_processingtimes[0][job];
            
            for (machine=1;machine<m_machines;machine++)
            {
                processingTime=m_processingtimes[machine][job];
                
                if (timeTable[machine-1]<timeTable[machine])
                {
                    timeTable[machine]+=processingTime;
                }
                else
                {
                    timeTable[machine]= timeTable[machine-1]+processingTime;
                }
            }
            
            fitness+=timeTable[m_machines-1];
        }
        
    }
    //Append the final job of the partial evaluation.
    //machine 0 is always incremental, so:
    timeTable[0]+=new_job_times[0];
    
    for (machine=1;machine<m_machines;machine++)
    {
        processingTime=new_job_times[machine];
        
        if (timeTable[machine-1]<timeTable[machine])
        {
            timeTable[machine]+=processingTime;
        }
        else
        {
            timeTable[machine]= timeTable[machine-1]+processingTime;
        }
    }
    
    fitness+=timeTable[m_machines-1];
    
    return fitness;
}

int PFSP::PartialEvaluation(int * genes, int size, int new_job)
{
    int timeTable[m_machines];
    int j,z, job,processingTime;
    int machine;
    int fitness=0;
    for (int i=0;i<m_machines;i++)	timeTable[i]=0;
    
    if (size!=0)
    {
        
        
        //int genes[20]={2,16,8,14,13,7,18,12,15,5,6,0,1,3,4,17,19,11,10,9};
        int first_gene=genes[0];
        timeTable[0]=m_processingtimes[0][first_gene];
        for (j=1;j<m_machines;j++)
        {
            timeTable[j]=timeTable[j-1]+m_processingtimes[j][first_gene];
        }
        
        fitness=timeTable[m_machines-1];
        
        for (z=1;z<size;z++)
        {
            job=genes[z];
            
            //machine 0 is always incremental, so:
            timeTable[0]+=m_processingtimes[0][job];
            
            for (machine=1;machine<m_machines;machine++)
            {
                processingTime=m_processingtimes[machine][job];
                
                if (timeTable[machine-1]<timeTable[machine])
                {
                    timeTable[machine]+=processingTime;
                }
                else
                {
                    timeTable[machine]= timeTable[machine-1]+processingTime;
                }
            }
            
            fitness+=timeTable[m_machines-1];
        }
        
    }
    
    //Append the final job of the partial evaluation.
    //machine 0 is always incremental, so:
    timeTable[0]+=m_processingtimes[0][new_job];
    
    for (machine=1;machine<m_machines;machine++)
    {
        processingTime=m_processingtimes[machine][new_job];
        
        if (timeTable[machine-1]<timeTable[machine])
        {
            timeTable[machine]+=processingTime;
        }
        else
        {
            timeTable[machine]= timeTable[machine-1]+processingTime;
        }
    }
    
    fitness+=timeTable[m_machines-1];
    return fitness;
}
