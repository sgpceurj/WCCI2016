//
//  Kendall.cpp
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#include "Kendall.h"
#include "Variables.h"
#include "Tools.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <climits>
using std::cerr;
using std::cout;
using std::endl;

/*
 * The constructor of the model.
 */
Kendall_Model::Kendall_Model(int problem_size, int sel_size)
{
	m_problem_size=problem_size;
    m_sample_size=sel_size;
    
    m_sampling_permutation= new int[m_problem_size];


    //sampling stage auxiliary data structures
    m_aux= new int[m_problem_size];
    aux_n= new int[m_problem_size];
 	m_Vjs = new int[m_problem_size];
    m_acum = new double[ m_problem_size ];
}

/*
 * The destructor of the model.
 */
Kendall_Model::~Kendall_Model()
{
    delete [] m_sampling_permutation;
    delete [] m_Vjs;

    //sampling stage auxiliary data structures
    delete [] m_aux;
    delete [] aux_n;
    delete [] m_acum;
}


/*
 * Builds the Mallows model for the Kendall distance with the given CR and theta parameters.
 */
bool Kendall_Model::Learn(CIndividual * individual, double theta)
{
  
    //1.- Copy the consensus ranking (the whole individual)
    m_individual=individual;
    
    //2.- Copy the theta parameter.
    m_theta_parameter= theta;
    
    return true;
}


/*
 * Generates a permutation to a given distance from the identity.
 */
void Kendall_Model::random_permu_at_dist_d( int dist, int*sigma, mpz_t ** count_matrix ){

    int i,j, rest_max_dist,max,pos,aux;
    double bound;
    for(i = 0 ; i < m_problem_size ;i ++ ) {
        aux=m_problem_size-i;
        rest_max_dist = ((aux - 1 ) * ( aux - 2 )) / 2;//con los restantes n' puedes tener distMAx de binom(n`)(2)
        if(rest_max_dist >= dist )
            m_acum[ 0 ] = mpz_get_d(count_matrix[ aux - 1 ][ dist ]);
        else
            m_acum[ 0 ] = 0 ;
        max = (aux < dist + 1 ) ? (aux ) : dist + 1;
        
        for( j = 1; j < max; j++ ){
            if((rest_max_dist + j) >= dist)
                m_acum[ j ] = m_acum[j-1] + mpz_get_d(count_matrix[ aux - 1 ] [ dist - j]);
            else
                m_acum[ j ] = 0;
        }
        
        bound = ((double)rand() / ((double)RAND_MAX + 1 ) ) * m_acum[ max - 1 ];

        pos = 0 ;
        while(m_acum[pos] <= bound)
            pos++;
        dist -= pos;
        m_Vjs[i] = pos;
    }
    for (j = i; j < m_problem_size; j++)
        m_Vjs[ j ] = 0; //the last n-i positions
    
    GeneratePermuFromV(m_Vjs, sigma);
}


/*
 * Given the consensus ranking, it samples a new individuals.
 */
int Kendall_Model::Sampling(std::discrete_distribution<> *distance_sampler,std::mt19937 * gen, mpz_t ** count_matrix, CPopulation * population, int num_samples, int * index_at_population, PFSP * problem)
{
    int s;
    double fitness=0;
    for (s=0;s<num_samples ;s++){
       // std::fill_n(m_aux, m_problem_size,-1);
        random_permu_at_dist_d((*distance_sampler)(*gen),m_aux,count_matrix);
        Compose(m_aux,m_individual->Genes(),m_sampling_permutation,m_problem_size); //original
        
        if (population->Exists(m_sampling_permutation, m_problem_size-1)==false){
            fitness=problem->EvaluateInv(m_sampling_permutation);
            population->m_individuals[population->m_pop_size+index_at_population[0]]->SetParameters(m_sampling_permutation,fitness);
            index_at_population[0]++;
            if (m_individual->Value()>fitness)
                m_individual->IncreaseBetterSamples();
        }
    }
    
    return num_samples;
}

/*
 * Generates a permutation from a v vector.
 */
void Kendall_Model::GeneratePermuFromV(int*v,int*permu)
{
    int val, i, index;
    for(i = 0 ; i < m_problem_size ; i ++) aux_n[i]=i;
    for(i = 0 ; i < m_problem_size - 1 ; i++){
        val = v[i];
        index = 0;
        while( !(aux_n[ index ] != -1 && val == 0))
            if(aux_n[ index ++ ] != -1)
                val --;
        permu[ i ] = index  ;
        aux_n[ index ] = -1 ;
    }
    index=0;
    while(aux_n[ index ] == -1 )index++;
    permu[ m_problem_size - 1 ] = index ;
}





