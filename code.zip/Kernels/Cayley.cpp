/*
 *  Cayley.cpp
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/18/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include "Cayley.h"
#include "Tools.h"
#include "Variables.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

using std::cerr;
using std::cout;
using std::endl;


/*
 * The constructor of the model.
 */
Cayley_Model::Cayley_Model(int problem_size, int sel_size)
{
	m_problem_size=problem_size;

    m_sample_size=sel_size;
    m_sampling_permutation= new int[m_problem_size];

    m_aux= new int [m_problem_size];
    m_long_cycle = new bool [ m_problem_size ];
    m_sigma_inv=new int[m_problem_size];
}

/*
 * The destructor of the model.
 */
Cayley_Model::~Cayley_Model()
{
    delete [] m_sampling_permutation;

    delete [] m_aux;
    delete [] m_sigma_inv;
    delete [] m_long_cycle;

}

/*
 * Builds the Mallows model for the Cayley distance with the given CR and theta parameters.
 */
bool Cayley_Model::Learn(CIndividual * individual, double theta)
{
    //1.- Copy the consensus ranking
    m_individual=individual;

    //2.- Copy the theta parameter.
    
	m_theta_parameter= theta;
    
	return true;
}


/*
 * Given the consensus ranking, it samples a new individual based on the stirling numbers, with big numbers.
 */
int Cayley_Model::Sampling(std::discrete_distribution<> *distance_sampler,std::mt19937 * gen, mpz_t ** stirling_matrix, CPopulation * population, int num_samples, int * index_at_population, PFSP * problem)
{
    double fitness;
    int i,j;

    //sample the solutions.
    for (i = 0 ; i < num_samples; i ++ ){

        generate_permu_with_k_cycles(m_problem_size,(m_problem_size-(*distance_sampler)(*gen)), m_aux, stirling_matrix);
        //Compose(m_aux, m_individual->Genes(), m_sampling_permutation, m_problem_size);
        for(j=0;j<m_problem_size;j++)
            m_sampling_permutation[j]=m_aux[m_individual->Genes()[j]];
        
        if (population->Exists(m_sampling_permutation, m_problem_size-1)==false){
            fitness=problem->EvaluateInv(m_sampling_permutation);
            population->m_individuals[population->m_pop_size+index_at_population[0]]->SetParameters(m_sampling_permutation,fitness);
            index_at_population[0]++;
        }
    }

    return num_samples;
}

/*
 * Generates a random permutation of the given size
 */
void Cayley_Model::generate_random_permutation(int len, int*sigma){
    //implements knuth shuffle (Fisher–Yates shuffle)
    //other option is to code Feller coupling
    int pos, aux, i;
    int len_1=len-1;
    for(i=0;i<len;i++) sigma[i]=i;
    for(i=0;i<len_1;i++){
        pos = rand() % (len_1) + i;
        aux= sigma[i];
        sigma[i]=sigma[pos];
        sigma[pos]=aux;
    }
}

/*
 * Generates a permutation with the given number of cycles.
 */
void Cayley_Model::generate_permu_with_k_cycles(int n, int k, int * sigma, mpz_t ** stirling_matrix){
    // n: 1..n_
    int ran2;
    long double  ran1 ;
    int i;
    double prov;
    mpf_t aux,aux2;
    mpf_init(aux);
    mpf_init(aux2);

    while ( k > 1 ){
        ran1 = ((double)rand() / ((double)RAND_MAX + 1 ) );
        mpf_set_z(aux,stirling_matrix[ n-1 ][ k - 1 ]);
        mpf_set_z(aux2,stirling_matrix[ n ][ k ]);
        mpf_div(aux,aux,aux2);
        prov=mpf_get_d(aux);
        if(ran1 < prov){
            m_long_cycle[ n-1 ] = false;
            k --;
        }else{
            m_long_cycle[ n-1 ] = true;
        }
        n --;
    }
    
    generate_random_permutation(n, m_sigma_inv);
    
    for ( i = 0 ; i < n-1; i ++ )
        sigma[m_sigma_inv[ i ]] = m_sigma_inv[i+1];
    sigma[m_sigma_inv[n-1]] =m_sigma_inv[0];
    
    for ( i = n ; i < m_problem_size ; i++){
        if ( m_long_cycle[ i ] ){
            ran2 = rand() % ( i ) ;
            sigma[ i ] = sigma[ ran2 ];
            sigma[ ran2 ] = i;
        }else{
            sigma[ i ] = i;
        }
    }
    mpf_clear(aux);
    mpf_clear(aux2);
}

