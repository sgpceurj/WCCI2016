//
//  VNS.cpp
//  Kernels
//
//  Created by Josu Ceberio Uribe on 19/06/15.
//  Copyright (c) 2015 University of the Basque Country. All rights reserved.
//

#include "VNS.h"
/*
 * The constructor.
 */
VNS::VNS(PFSP * problem, int problem_size, long int max_evaluations){
    m_problem=problem;
    m_problem_size=problem_size;
    m_max_evaluations=max_evaluations;
    m_evaluations=0;
    m_convergence_evaluations=0;
    m_aux= new int[m_problem_size];
    m_best= new CIndividual(m_problem_size);
    
    m_insert_best= new int [m_problem_size];
    m_insert_perm_aux= new int[m_problem_size];
}

/*
 * The destructor.
 */
VNS::~VNS(){
    
    delete m_best;
    delete [] m_aux;
    delete [] m_insert_best;
    delete [] m_insert_perm_aux;
}
double VNS::Run_PopulationBased(CPopulation * population, int first_individuals,int shake_power,int trials){
    
    //select the most sparse set of the population including the best
    vector<int> m_selected;
    vector<int> m_not_selected;
    //Initialize lists
    int i,j,dist,index_pos,max_dist;

    for (i=1;i<population->m_pop_size;i++)
        m_not_selected.push_back(i);
    m_selected.push_back(0);

    
    // Find the set of solutions that maximizes the spread sub-set problem.
    for (i=1;i<first_individuals;i++){
        index_pos=0;
        max_dist=0;
        for (j=0;j<m_not_selected.size();j++)
        {
            dist=HammingDistance(population->m_individuals[m_not_selected[j]]->Genes(),population->m_individuals[m_selected[m_selected.size()-1]]->Genes(),m_problem_size);
            if (max_dist<dist){
                max_dist=dist;
                index_pos=j;
            }
        }
        m_selected.push_back(m_not_selected[index_pos]);
        m_not_selected.erase(m_not_selected.begin()+index_pos);
    }
    
    //run the Population based VNS
    int individ=first_individuals;
    while (m_evaluations<m_max_evaluations){
        for (i=0;i<individ && m_evaluations<m_max_evaluations;i++){
            this->Run(population->m_individuals[m_selected[i]], shake_power,trials);
            population->m_individuals[m_selected[i]]->SetParameters(m_best->Genes(), m_best->Value());
        }
    }
    population->SortPopulation(0);
    return population->m_individuals[0]->Value();
    
}
/*
 * Running function
 */
double VNS::Run(CIndividual * init, int shake_power, int trials){
    
    bool seguir=true;
    int iteracion=0;
    int non_improvement=0;
//    cout<<"VNS...m_evaluations: "<<m_evaluations<<"  m_max_evaluations: "<<m_max_evaluations<<endl;

#ifdef PRINT_LOG
    cout<<init<<endl;
#endif
    //size_t size_copy=sizeof(int)*m_problem_size;
    //save best individual
    m_best->SetGenes(init->Genes());
    m_best->SetValue(init->Value());
    CIndividual * current = init->Clone();
    do
    {
        do
        {
           // cout<<"Swap LS running...before: "<<current->Value();
            LocalSearch_Greedy_Swap2(current);
          //  cout<<"... after: "<<current->Value()<<"... evaluations: "<<m_evaluations<<endl;
          //  cout<<"Insert LS running...before: "<<current->Value();
            seguir=  LocalSearch_Greedy_Insert3(current);
          //  cout<<"... after: "<<current->Value()<<"... evaluations: "<<m_evaluations<<endl;
        }
        while (seguir && m_evaluations<m_max_evaluations);
        
        if (current->Value()<m_best->Value()){
            m_best->SetParameters(current->Genes(), current->Value());
            non_improvement=0;
        }
        else
        {
            current->SetParameters(m_best->Genes(), m_best->Value());
            non_improvement++;
        }
        
        //shake.
        current->Shake_Insert(shake_power);
//        Shake_Swap(current,shake_power);
        current->SetValue(m_problem->Evaluate(current->Genes())); m_evaluations++;
#ifdef PRINT_LOG
        cout<<"iteracion: "<<iteracion<<" fitness: "<<m_best->Value()<<" evals rem: "<<m_max_evaluations-m_evaluations<<endl;
#endif
        iteracion++;

    }
    while (m_evaluations<m_max_evaluations && non_improvement<trials);

    delete current;
    
    return m_best->Value();
}

/*
 * Returns the number of performed evaluations.
 */
long int VNS::GetPerformedEvaluations(){
    return m_convergence_evaluations;
}

/*
 * Returns the fitness of the best solution obtained.
 */
double VNS::GetBestSolutionFitness(){
    return m_best->Value();
}

/*
 * Returns the best solution obtained.
 */
CIndividual * VNS::GetBestSolution(){
    return m_best;
}

/*
 * It applies random shake_power times a perturbation over the given individual.
 */
void VNS::Shake_Swap(CIndividual *  individual, int shake_power)
{
    //shake_power= rand() % shake_power;
    int * genes= individual->Genes();
    int i,j,aux;
    for (int iter=0;iter<shake_power;iter++)
    {
        //permute randomly genes in position i and j to scape the stackeness in both neighborhood.
        i = rand() % m_problem_size;
        j = rand() % m_problem_size;
        aux=genes[j];
        genes[j]=genes[i];
        genes[i]=aux;
        //cout<<individual<<endl;
    }
    //individual->SetGenes(genes);
}


/*
 * This method applies a greedy local search with the swap operator neighborhood with the given power.
 */
bool VNS::LocalSearch_Greedy_Swap2(CIndividual *  individual)
{
    float cost_opt, cost_improve, cost_best_provisional;
    int seguir,j,k,aux;
    int best_k=0, best_j=0;
    
    Invert(individual->Genes(),m_problem_size, m_aux);
    
    cost_opt=individual->Value();
    cost_best_provisional=cost_opt;
    int iter=0;
    seguir=1;
    while (seguir && m_evaluations<m_max_evaluations)
    {
        seguir=0;
        for (k=0; k<m_problem_size-1 && m_evaluations<m_max_evaluations; k++)
        {
            for (j=k+1; j<m_problem_size && m_evaluations<m_max_evaluations;j++)
            {
                //swap k and j positions.
                aux=m_aux[k];
                m_aux[k]=m_aux[j];
                m_aux[j]=aux;
                
                cost_improve=m_problem->Evaluate(m_aux);    m_evaluations++;
               
                if (cost_improve<cost_best_provisional)
                {
                    //guardar que el mejor swap
                    //cout<<"Local Search Improvement (Greedy non adjacent)!!"<<endl;
                    best_k=k;
                    best_j=j;
                    cost_best_provisional=cost_improve;
                    m_convergence_evaluations=m_evaluations;
                    seguir=1;
                }
                
                //restore the positions swapped previously. Because this change does not produce good results.
                aux=m_aux[j];
                m_aux[j]=m_aux[k];
                m_aux[k]=aux;
            }
        }
        
        if (seguir==1)
        {
            //modificar la permutacion con aquel swap que mejore más.
            aux=m_aux[best_k];
            m_aux[best_k]=m_aux[best_j];
            m_aux[best_j]=aux;
            //cost_opt=m_problem->Evaluate(m_aux);    m_evaluations++;
            cost_opt=cost_best_provisional;
        }
        iter++;
    }
    Invert(m_aux,m_problem_size,individual->Genes());
    individual->SetValue(cost_opt);
   // cout<<individual<<endl;
    if (best_j==0 && best_k==0)//si estas variables siguen sin utilizar quiere decir que no se ha mejorado.
        return false;
    else
        return true;
    
}

bool VNS::LocalSearch_Greedy_Insert3(CIndividual *  individual)
{
    bool Improvement=false;
    int cost_opt, cost_improve, cost_best_provisional;
    int seguir, i,j;
    
    Invert(individual->Genes(),m_problem_size, m_aux);
    memcpy(m_insert_best,m_aux,sizeof(int)*m_problem_size);

    cost_opt=individual->Value();
    cost_best_provisional=cost_opt;
    size_t size_copy=sizeof(int)*m_problem_size;
    seguir=1;
    int iter=0;
    while (iter<1 && m_evaluations<m_max_evaluations)
    {
        seguir=0;
        //forward step
        for (i=0;i<(m_problem_size-1) && m_evaluations<m_max_evaluations;i++)
        {
            memcpy(m_insert_perm_aux,m_aux,size_copy);
            Swap(m_insert_perm_aux,i,i+1);
            cost_improve=m_problem->Evaluate(m_insert_perm_aux);    m_evaluations++;
            if (cost_improve<cost_best_provisional)
            {
                memcpy(m_insert_best,m_insert_perm_aux,size_copy);
                cost_best_provisional=cost_improve;
                m_convergence_evaluations=m_evaluations;
                seguir=1;
            }
            
            for (j=i+1; j<(m_problem_size-1) && m_evaluations<m_max_evaluations;j++)
            {
                Swap(m_insert_perm_aux,j,j+1);
                cost_improve=m_problem->Evaluate(m_insert_perm_aux);    m_evaluations++;
                if (cost_improve<cost_best_provisional)
                {
                    memcpy(m_insert_best,m_insert_perm_aux,size_copy);
                    cost_best_provisional=cost_improve;
                    m_convergence_evaluations=m_evaluations;
                    seguir=1;
                }
            }
        }
        
        //backward step
        Swap(m_aux,0,1);
        for (i=2;i<m_problem_size && m_evaluations<m_max_evaluations;i++)
        {
            Swap(m_aux,0,i);
            
            memcpy(m_insert_perm_aux,m_aux,size_copy);
            cost_improve=m_problem->Evaluate(m_insert_perm_aux);    m_evaluations++;
            if (cost_improve<cost_best_provisional)
            {
                memcpy(m_insert_best,m_insert_perm_aux,size_copy);
                cost_best_provisional=cost_improve;
                m_convergence_evaluations=m_evaluations;
                seguir=1;
            }
            for (j=0;j<(i-2) && m_evaluations<m_max_evaluations;j++)
            {
                Swap(m_insert_perm_aux,j,j+1);
                cost_improve=m_problem->Evaluate(m_insert_perm_aux);    m_evaluations++;
                
                if (cost_improve<cost_best_provisional)
                {
                    memcpy(m_insert_best,m_insert_perm_aux,size_copy);
                    cost_best_provisional=cost_improve;
                    m_convergence_evaluations=m_evaluations;
                    seguir=1;
                }
            }
        }
        
        if (seguir==1)
        {
            Improvement=true;
            memcpy(m_aux,m_insert_best,size_copy);
//            cost_opt=m_problem->Evaluate(m_aux);
            cost_opt=cost_best_provisional;
//            cout<<"cost_opt "<<cost_opt<<" & cost_best_provisional: "<<cost_best_provisional<<endl;
        }
        iter++;
    }
    memcpy(m_aux,m_insert_best,size_copy);
    Invert(m_aux,m_problem_size,individual->Genes());
    individual->SetValue(cost_opt);
    return Improvement;
}
