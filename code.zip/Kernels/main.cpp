//
//  main.cpp
//  Kernels
//
//  Created by Josu Ceberio Uribe on 30/01/15.
//  Copyright (c) 2015 University of the Basque Country. All rights reserved.
//
#include <sys/time.h>
#include <iostream>
#include <iomanip>
#include "KernelRankingEDA.h"
#include "PFSP.h"
#include "VNS.h"

//It is the instance of the problem to optimize.
PFSP * PROBLEM;

// The individual size.
int PROBLEM_SIZE;

// The population size.
int POP_SIZE=-1;

// The selection pool size.
double SEL_SIZE=-1;

// The theta value predefined.
double THETA=-1;

// Maximum number of restarts to perform.
int MAX_RESTARTS=10;

// Maximum number of non-improvement iterations before restart.
int RESTART_COUNTDOWN=500;

// Number of jobs moved in a restart shake of insert operations.
int RESTART_SHAKE_POWER=5;
double RATIO_RESTART_SHAKE_POWER=1;

// Number of jobs moved in a VNS shake of insert operations.
int VNS_SHAKE_POWER=10;
double RATIO_VNS_SHAKE_POWER=1;

// The evaluations ratio devoted to the EDA. The rest goes to VNS.
double TWO_FOLD_RATIO=0.5;

// Number of evaluations performed.
long int EVALUATIONS = 0;

// Convergence evaluation of the best fitness.
long int CONVERGENCE_EVALUATIONS = 0;

// Maximum number of evaluations allowed performed.
long int MAX_EVALUATIONS = 0;

// Name of the file where the result will be stored.
char RESULTS_FILENAME[1024];

// Name of the file where the instances is stored.
char INSTANCE_FILENAME[1024];

// The seed asigned to the process
int SEED=5;


/*
 * Get next command line option and parameter
 */
int GetOption (int argc, char** argv, char* pszValidOpts, char** ppszParam)
{
    
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;
    
    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
        
        if (*psz == '-' )//|| *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
            
            if (isalnum(chOpt) || ispunct(chOpt))
            {
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
                
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' )//|| *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }
                            
                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }
    
    iArg++;
    
    *ppszParam = pszParam;
    return (chOpt);
}

/*
 * Help command output.
 */
void usage(char *progname)
{
    cout << "./Kernels -i <instance_name> -o <results_name> -s <seed> -p <pop_size> -l <sel_size> -g <theta> -r <max_restarts> -t <two_fold_ratio> -m <iterations_no_improvement> -b <restart_shake_power_ratio> -v <vns_shake_power_ratio>" <<endl;
    cout <<"   -i File name of the instance.\n"<<endl;
    cout <<"   -o Name of the file to store the results.\n"<<endl;
    cout <<"   -s Seed to be used for pseudo-random numbers generator.\n"<<endl;
    cout <<"   -p population size.\n"<<endl;
    cout <<"   -l selection size.\n"<<endl;
    cout <<"   -g theta parameter.\n"<<endl;
    cout <<"   -r max_restarts.\n"<<endl;
    cout <<"   -t two fold ratio.\n"<<endl;
    cout <<"   -b restart shake power ratio(percentage of the number of jobs moved from position in the restart).\n"<<endl;
    cout <<"   -v VNS shake power ratio (percentage of the number of jobs moved from position in the VNS).\n"<<endl;
    cout <<"   -m iterations without improvement before restart.\n"<<endl;
}

/*
 * Obtaint the execution parameters from the command line.
 */
bool GetParameters(int argc,char * argv[])
{
    char c;
    if(argc==1)
    {
        usage(argv[0]);
        return false;
    }
    char** optarg;
    optarg = new char*[argc];
    while ((c = GetOption (argc, argv, "s:h:o:i:t:p:g:r:m:b:v:l:",optarg)) != '\0')
    {
        switch (c)
        {
                
            case 'h' :
                usage(argv[0]);
                return false;
                break;
                
            case 's' :
                SEED = atoi(*optarg);
                break;
                
            case 'o' :
                strcpy(RESULTS_FILENAME, *optarg);
                break;
                
            case 'i':
                strcpy(INSTANCE_FILENAME, *optarg);
                break;
                
            case 't':
                TWO_FOLD_RATIO=atof(*optarg);
                break;

            case 'g':
                THETA=atof(*optarg);
                break;
                
            case 'p':
                POP_SIZE=atoi(*optarg);
                break;
                
            case 'l':
                SEL_SIZE=atoi(*optarg);
                break;
                
            case 'r':
                MAX_RESTARTS=atoi(*optarg);
                break;
            
            case 'm':
                RESTART_COUNTDOWN=atoi(*optarg);
                break;
                
            case 'b':
                RATIO_RESTART_SHAKE_POWER=atof(*optarg);
                break;
                
            case 'v':
                RATIO_VNS_SHAKE_POWER=atof(*optarg);
                break;
        }
    }
    
    delete [] optarg;
    
    return true;
}

/*
 * Writes the results of the execution.
 */
void WriteResults(double best_fitness, int * best, long int evaluations, long double time_interval){
    
    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file<<"Best fitness: "<<setprecision(15)<<best_fitness<<endl;
    output_file<<"Best solution: ";
    for (int i=0;i<PROBLEM_SIZE;i++)
        output_file<<best[i]<<" ";
    output_file<<endl;
    output_file<<"Evaluations performed: "<<setprecision(15)<<evaluations<<endl;
    output_file<<"Ratio performed: "<<setprecision(15)<<(double)evaluations/(double)MAX_EVALUATIONS<<endl;
    output_file<<"Time consumed: "<<time_interval<<endl;
    output_file.close();
}

/*
 * Writes the results of the execution.
 */
void WriteResults(double best_fitnessVNS, int * best, double best_fitnessEDA, long int evaluationsEDA, long int evaluationsVNS, long double time_interval){
    
    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file<<"BestFitness Twofold: "<<setprecision(15)<<best_fitnessVNS<<endl;
    output_file<<"Best solution: ";
    for (int i=0;i<PROBLEM_SIZE;i++)
        output_file<<best[i]<<" ";
    output_file<<endl;
    output_file<<"BestFitness EDA: "<<setprecision(15)<<best_fitnessEDA<<endl;
    output_file<<"Evaluations EDA: "<<setprecision(15)<<evaluationsEDA<<endl;
    output_file<<"Evaluations VNS: "<<setprecision(15)<<evaluationsVNS<<endl;
    output_file<<"Time consumed: "<<time_interval<<endl;
    output_file.close();
}
/*
 * Reads the problem info of the instance set.
 */
PFSP * GetProblemInfo(string filename)
{
    //Read the instance.
    PFSP * problem= new PFSP();
    int problem_size= problem->Read(filename);
    PROBLEM_SIZE=problem_size;
    
    return problem;
}

/*
 * This method returns the corresponding evaluations number to the parameters n (jobs) and m (machines).
 * The evaluations are calculated from one execution of the AGA algorithm for each type of instance with the
 * stopping criteria of n*m*0.4 seconds.
 */
int GetEvaluationsNumber(int n, int m)
{
    switch (n)
    {
        case 20:
            if(m==5)
                return 182224100;
            else if (m==10)
                return 224784800;
            else
                return 256896400;
            break;
            
        case 50:
            if(m==5)
                return 220712150;
            else if (m==10)
                return 256208100;
            else
                return 275954150;
            break;
            
        case 100:
            if(m==5)
                return 235879800;
            else if(m==10)
                return 266211000;
            else
                return 283040000;
            break;
            
        case 200:
            if (m==10)
                return 272515500;
            else
                return 287728850;
            break;
            /** RANDOM INSTANCES EVALUATIONS **/
            
        case 250:
            if (m==10)
                return 267779100;
            else
                return 284574350;
            break;
            
        case 300:
            if (m==10)
                return 273847500;
            else
                return 284672900;
            break;
            
        case 350:
            if (m==10)
                return 278369000;
            else
                return 286225300;
            break;	
            
        case 400:
            if (m==10)
                return 275491800;
            else
                return 283913500;
            break;
            
        case 450:
            if (m==10)
                return 277455350;
            else
                return 269271450;
            break;
            /** END RANDOM INSTANCES EVALUATIONS **/
        case 500:
            return 260316750;
            break;
            
        default:
            return n*1000000;
            break;
    }
}

/*
 * This method returns the corresponding configurations of the parameters of the algorithm
 * obtained by applying the bayesian optimization.
 */
void BayesianParameterTunning(int n, int m)
{
    switch (n)
    {

        case 100:
            if(m==10){ //20 repeticiones.
                THETA=11.91;
                VNS_SHAKE_POWER=9.0;
                POP_SIZE=1831;
                RESTART_SHAKE_POWER=78;
                RESTART_COUNTDOWN=234;
                MAX_RESTARTS=99;
            }
            else if (m==20){ //10 errepikapen egingo ditugu
                THETA=14.46;
                VNS_SHAKE_POWER=15;
                POP_SIZE=1118;
                RESTART_SHAKE_POWER=63;
                RESTART_COUNTDOWN=632;
                MAX_RESTARTS=23;
            }
            break;
        case 200:
            if(m==10){ //10 repeticiones.
                THETA=1;
                VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            else if (m==20){ //10 repeticiones
                THETA=1;
                VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            break;
        case 300:
            if(m==10){ //10 repeticiones.
                THETA=1;
                VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            else if (m==20){ //10 repeticiones
                THETA=1;
                VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            break;
        case 400:
            if(m==10){ //10 repeticiones.
                THETA=1;
                VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            else if (m==20){ //10 repeticiones
                THETA=1;
                VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            break;
        case 500:
            if (m==20){ //10 repeticiones
                THETA=1;
                VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            break;
        default:
            THETA=1;
            VNS_SHAKE_POWER=1;
            POP_SIZE=1;
            RESTART_SHAKE_POWER=1;
            RESTART_COUNTDOWN=1;
            MAX_RESTARTS=1;

            break;
    }
}

/*
 * This method returns the corresponding configurations of the parameters of the algorithm
 * obtained by applying the bayesian optimization.
 */
void BayesianParameterTunning_WCCI(int n, int m)
{
    switch (n)
    {
        case 50:
            if(m==10){ //10 repeticiones.
                THETA=11.22;
                RATIO_VNS_SHAKE_POWER=0.076;
                POP_SIZE=700;
                RATIO_RESTART_SHAKE_POWER=0.29;
                RESTART_COUNTDOWN=876;
                MAX_RESTARTS=92;
                
            }
            else if (m==20){ //10 repeticiones
                THETA=14.83;
                RATIO_VNS_SHAKE_POWER=0.37;
                POP_SIZE=428;
                RATIO_RESTART_SHAKE_POWER=0.81;
                RESTART_COUNTDOWN=555;
                MAX_RESTARTS=56;
            }
            break;
        case 100:
            if(m==10){ //20 repeticiones.
                THETA=1;
                RATIO_VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RATIO_RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;

            }
            else if (m==20){ //10 errepikapen egingo ditugu
                THETA=1;
                RATIO_VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RATIO_RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            break;
        case 200:
            if(m==10){ //10 repeticiones.
                THETA=13.38;
                RATIO_VNS_SHAKE_POWER=0.02;
                POP_SIZE=783;
                RATIO_RESTART_SHAKE_POWER=0.177;
                RESTART_COUNTDOWN=609;
                MAX_RESTARTS=90;
            }
            else if (m==20){ //10 repeticiones
                THETA=14.78;
                RATIO_VNS_SHAKE_POWER=0.018;
                POP_SIZE=955;
                RATIO_RESTART_SHAKE_POWER=0.1759;
                RESTART_COUNTDOWN=896;
                MAX_RESTARTS=73;
            }
            break;
        case 300:
            if(m==10){ //10 repeticiones.
                THETA=1;
                RATIO_VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RATIO_RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            else if (m==20){ //10 repeticiones
                THETA=1;
                RATIO_VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RATIO_RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            break;
        case 400:
            if(m==10){ //10 repeticiones.
                THETA=1;
                RATIO_VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RATIO_RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            else if (m==20){ //10 repeticiones
                THETA=1;
                RATIO_VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RATIO_RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            break;
        case 500:
            if (m==20){ //10 repeticiones
                THETA=1;
                RATIO_VNS_SHAKE_POWER=1;
                POP_SIZE=1;
                RATIO_RESTART_SHAKE_POWER=1;
                RESTART_COUNTDOWN=1;
                MAX_RESTARTS=1;
            }
            break;
        default:
            THETA=1;
            RATIO_VNS_SHAKE_POWER=1;
            POP_SIZE=1;
            RATIO_RESTART_SHAKE_POWER=1;
            RESTART_COUNTDOWN=1;
            MAX_RESTARTS=1;
            break;
    }
}

/*
 * Main function.
 */
int main(int argc, char * argv[])
{
    
    //Initialize time variables.
    struct timeval tim;
    gettimeofday(&tim, NULL);
    double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
    
    //Get parameters
    if(!GetParameters(argc,argv)) return -1;
    
    //Set seed
    srand(SEED*1000);
    
    //Read the problem instance to optimize.
    PROBLEM = GetProblemInfo(INSTANCE_FILENAME);
    
    MAX_EVALUATIONS=GetEvaluationsNumber(PROBLEM->m_jobs, PROBLEM->m_machines);
    
#ifdef BAYESIAN_PARAMETERS
    if (BAYESIAN_PARAMETERS==0)
        BayesianParameterTunning(PROBLEM->m_jobs, PROBLEM->m_machines);
    else { //BAYESIAN_PARAMETERS==1
        BayesianParameterTunning_WCCI(PROBLEM->m_jobs, PROBLEM->m_machines);
    }
#endif
    
    //Initialize the algorithm
    long int evaluations, evaluations2;
    CIndividual * best;

#ifndef TWO_STEP

    KernelRankingEDA * alg= new KernelRankingEDA(PROBLEM, PROBLEM_SIZE, MAX_EVALUATIONS, POP_SIZE, SEL_SIZE, THETA, MAX_RESTARTS, RESTART_COUNTDOWN);
    
    double best_fitness=alg->Run();

    //Get best solution fitness and the number of evaluations performed.
    evaluations = alg->GetPerformedEvaluations();
    best = alg->GetBestSolution();
#else
    PROBLEM_SIZE=PROBLEM->m_jobs;
#ifndef BAYESIAN_PARAMETERS
    POP_SIZE=PROBLEM_SIZE*10;
    RESTART_SHAKE_POWER=5;
    VNS_SHAKE_POWER=10;
    RESTART_COUNTDOWN=500;
    THETA=-1; // the KernelRankingEDa will set later P(\sigma_0)=0.9;
    MAX_RESTARTS=10*PROBLEM_SIZE;
#else
    RESTART_SHAKE_POWER=(int)PROBLEM->m_jobs*RATIO_RESTART_SHAKE_POWER;
    VNS_SHAKE_POWER=PROBLEM->m_jobs*RATIO_VNS_SHAKE_POWER;
#endif
    KernelRankingEDA * alg= new KernelRankingEDA(PROBLEM, PROBLEM_SIZE, MAX_EVALUATIONS*TWO_FOLD_RATIO, POP_SIZE, SEL_SIZE, THETA, MAX_RESTARTS, RESTART_COUNTDOWN,RESTART_SHAKE_POWER);

   double best_fitness1=alg->Run();
    evaluations = alg->GetPerformedEvaluations();
    best = alg->GetBestSolution();
    

    //Get best solution fitness and the number of evaluations performed.
    VNS * alg2= new VNS(PROBLEM, PROBLEM_SIZE, MAX_EVALUATIONS-alg->m_evaluations);
    double best_fitness2= alg2->Run(best, VNS_SHAKE_POWER,INT_MAX);

#ifdef PRINT_LOG
    cout<<"VNS best fitness: "<<best_fitness2<<endl;
#endif
    best=alg2->GetBestSolution();
    evaluations2 = alg2->GetPerformedEvaluations();
    
#endif
    gettimeofday(&tim, NULL);
    double t2=tim.tv_sec+(tim.tv_usec/1000000.0);
    
    //Create the file to store the results.
    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file.close();

#ifndef TWO_STEP
    //Print results
    WriteResults(best->Value(),best->Genes(),evaluations,t2-t1);
    delete alg;
    printf("%d\n",(int)best_fitness);
    return best_fitness;

#else
    WriteResults(best->Value(),best->Genes(),best_fitness1,evaluations,evaluations2,t2-t1);
    delete alg;
    delete alg2;
    printf("%d\n",(int)best_fitness2);
    return best_fitness2;
#endif
  }

