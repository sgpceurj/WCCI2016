//
//  Individual.cc
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#include "Individual.h"
#include "Tools.h"

// The object storing the values of all the individuals
// that have been created during the execution of the
// program. 

CIndividual::CIndividual(int length)
{
	m_size = length;
	m_genes = new int[m_size];
    m_value=MAX_INTEGER;
    m_generations=0;
    m_better_samples=0;
}

/*
 * The descructor of the class individual
 */
CIndividual::~CIndividual()
{
	delete [] m_genes;
	m_genes=NULL;
}

/*
 * Returns the fitness value of the solution.
 */
double CIndividual::Value()
{
	return m_value;
}

/*
 * Returns the genes of the individual.
 */
int * CIndividual::Genes()
{
	return m_genes;
}


/*
 * Returns the size of an individual
 */
int CIndividual::Size(){
    return m_size;
}

/*
 * Returns the age (generation) of an individual.
 */
int CIndividual::Generation(){
    return m_generations;
}

/*
 * Returns the age (generation) of an individual.
 */
int CIndividual::BetterSamples(){
    return m_better_samples;
}

/*
 * Output operator.
 */
ostream & operator<<(ostream & os,CIndividual * & individual)
{
    os <<individual->m_value<<"     ";
    os << individual->m_genes[0];
	for(int i=1;i<individual->m_size;i++)
        os << " " << individual->m_genes[i];
	return os;
}

/*
 * Input operator.
 */
istream & operator>>(istream & is,CIndividual * & individual)
{
  char k; //to avoid intermediate characters such as ,.

  is >> individual->m_value;
  is >> individual->m_genes[0];
  for(int i=1;i<individual->m_size;i++)
    is >> k >> individual->m_genes[i];
  is >> k;

  return is;
}

/*
 * Sets the given value as the new fitness of the individual.
 */
void CIndividual::SetValue(double value)
{
	m_value=value;
    m_generations=0;
    m_better_samples=0;
}

/*
 * Sets the given array of ints as the genes of the individual.
 */
void CIndividual::SetGenes(int * genes)
{
	memcpy(m_genes, genes, sizeof(int)*m_size);
	m_value=MAX_INTEGER;
    m_generations=0;
    m_better_samples=0;
}

/*
 * Sets the given array of ints as the genes of the individual.
 */
void CIndividual::SetParameters(int * genes, double fitness)
{
    memcpy(m_genes, genes, sizeof(int)*m_size);
    m_value=fitness;
    m_generations=0;
    m_better_samples=0;
}


/*
 * Prints in the standard output genes.
 */
void CIndividual::PrintGenes()
{
	for (int i=0;i<m_size;i++){
		cout<<m_genes[i]<<" ";
	}
	cout<<" "<<endl;
}

/*
 * Increases the generation of the individual by one.
 */
void CIndividual::IncreaseGeneration(){
    m_generations++;
}

/*
 * Increases the number of better samples by one.
 */
void CIndividual::IncreaseBetterSamples(){
    m_better_samples++;
}

/*
 * Clones the individual.
 */
CIndividual * CIndividual::Clone()
{
	CIndividual * ind = new CIndividual(m_size);
	ind->SetGenes(m_genes);
	ind->SetValue(m_value);
    ind->m_generations=m_generations;
	return ind;
}

/*
 * It applies random shake_power times a perturbation over the given individual.
 */
void CIndividual::Shake_Insert(int shake_power)//, int orbit_size)
{
    
    int * inverted= new int[m_size];
    Invert(m_genes, m_size, inverted);
    int i,j;
    
    int min_range,max_range,val;
    int half_orbit=5;
    for (int iter=0;iter<shake_power;iter++)
    {
        //permute randomly genes in position i and j to scape the stackeness in both neighborhood.
        i = rand() % m_size;
        //j = rand() % m_size;
        
        min_range=MAX(i-half_orbit,0);
        max_range=MIN(i+half_orbit,m_size-1);
        val = rand() % (max_range-min_range);
        j= min_range+val;
        
        InsertAt(inverted,i,j,m_size);
    }
    Invert(inverted, m_size, m_genes);
    m_value=MIN_LONG_INTEGER;
    m_generations=0;
    m_better_samples=0;
    delete[] inverted;
}


