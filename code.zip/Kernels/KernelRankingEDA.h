//
//  KernelRankingEDA.h
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 16/01/15.
//  Copyright (c) 2015 Josu Ceberio Uribe. All rights reserved.
//

#ifndef __RankingEDAsCEC__KernelRankingEDA__
#define __RankingEDAsCEC__KernelRankingEDA__

#include <stdlib.h>
#include <stdio.h>
#include "PFSP.h"
#include "Individual.h"
#include "Population.h"
#include "Cayley.h"
#include "Kendall.h"
#include "Tools.h"
#include <list>
#include <gmp.h>
#include <random>
using namespace std;

class KernelRankingEDA
{
    
public:
    
    /*
     * The size of the selection pool.
     */
    int m_sel_size;

    /*
     * The number of kernels to learn.
     */
    int m_kernel_num;
    
    /*
     * Problem
     */
    PFSP * m_problem;
    
    /*
     * Problem size
     */
    int m_problem_size;
    
    /*
     * Maximum number of evaluations permitted in the execution.
     */
    long int m_max_evaluations;
    
    /*
     * The number of evaluations performed at the moment.
     */
    long int m_evaluations;
    
    /*
     * The number of the evaluations performed to achieve the best solution so far.
     */
    long int m_convergence_evaluations;
    
    /*
     * The best solution found so far.
     */
    CIndividual * m_best;
    
    /*
     * The size of the population.
     */
    int m_pop_size;
    
    /*
     * Maximum number of restarts.
     */
    int m_max_restarts;
    
    /*
     * Number of jobs shaken in a restart.
     */
    int m_restart_shake_power;
    
    /*
     * Maximum number of iterations no improvement before restart.
     */
    int m_restart_countdown;
    
    /*
     * The size of the offspring population.
     */
    int m_offspring_size;
    
    /*
     * Array to store the acum weights of each kernel to be used in the sampling.
     */
    float * m_acum_ratios;
    
    /*
     * Array to store the number of individuals that are samples from each sample.
     */
    int * m_samples_from_each_kernel;
    
    /*
     * The population
     */
    CPopulation * m_population;

    /*
     * The list of kernels of Mallows models under the Cayley distance.
     */
    list<Cayley_Model *> m_models;
    
    /*
     * The iterator variable used to access the list of kernelsof Mallows models under the Cayley distance.
     */
    list<Cayley_Model*>::iterator m_iterator;
    list<Cayley_Model*>::iterator m_iterator_last;


    vector<int> m_selected;
    vector<int> m_not_selected;
    

    
    /*
     * The theta parameter
     */
    double m_theta_parameter;

    /*
     * Auxiliary structures to sample solutions from discrete_distribution.
     */
    list<double> m_probabilities_list;
    random_device m_rd;

    //Data structures for Cayley and Kendall
    mpz_t * gmp_factorials;
    mpz_t ** gmp_count_matrix;
    mpf_t * gmp_acumul;
    
    /*
     * The constructor.
     */
    KernelRankingEDA(PFSP * problem, int problem_size, long int max_evaluations, int pop_size, double sel_size, double theta, int max_restarts, int restart_countdown, int restart_shake_power);
    
    /*
     * The destructor.
     */
    virtual ~KernelRankingEDA();
            
    /*
     * Running function
     */
    double Run();
    
    /*
     * Returns the number of performed evaluations.
     */
    long int GetPerformedEvaluations();
    
    /*
     * Returns the fitness of the best solution obtained.
     */
    double GetBestSolutionFitness();
    
    /*
     * Returns the best solution obtained.
     */
    CIndividual * GetBestSolution();
    
    
private:
    
    /*
     * Calculates the position of the individual in the not_selected vector that maximizes the sum of the distances to the individuals in the selected vector.
     */
    int SolutionToMaxDistanceToSelected(vector<int> selected, vector<int> not_selected);
    
    /*
     * Returns the theta value that P(\sigma_0)=0.9 with the Mallows model under the Cayley distance for the specified problem size.
     */
    double GetTheta_Cayley9(int problem_size);
    
    /*
     * Returns the theta value that P(\sigma_0)=0.8 with the Mallows model under the Cayley distance for the specified problem size.
     */
    double GetTheta_Cayley8(int problem_size);
    /*
     * Learns the kernels of the specified model by means.
     */
    void Learn(CPopulation * population);
    
    /*
     * Learns the kernels of the specified model by means.
     */
    void Learn_MaxSSP(CPopulation * population);
    
    /*
     * Samples solutions from the mixture model learnt using the Stochastic Universal Sampling (SUS). Returns the number of sampled solutions.
     */
    int Sample(CPopulation * population, std::discrete_distribution<> *distance_sampler,std::mt19937 * gen, int num_samples, PFSP * problem);
    
    /*
     * Initializes the stirling matrix numbers for the sampling of Kernels of Mallows-Cayley models.
     */
    void Initialize_StirlingMatrix();
    
    /*
     * Initializes the population of the EDA.
     */
    void PopulationInitialization(int pop_size, int off_size);
    
    /*
     * Calculates the probability of sampling permutations to different distances under the Mallows model with the Cayley distance.
     */
    void Cayley_DataStructure_Initialization();
    
    /*
     * Calculates the Hamming distance between 2 permutations.
     */
    int HammingDistance(int* permutationA, int*permutationB);

};

#endif 
