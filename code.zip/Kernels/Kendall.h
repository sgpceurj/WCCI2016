//
//  Kendall.h
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#ifndef _KENDALL_
#define _KENDALL_

#include "PFSP.h"
#include "Population.h"
#include <gmp.h>
#include <random>


class Kendall_Model 
{
public:

    /*
     * Problem size.
     */
    int m_problem_size;
    
    /*
     * Sample size.
     */
    int m_sample_size;
    
    /*
     * Spread parameters vector.
     */
    double m_theta_parameter;
    
    /*
     * The whole individual
     */
    CIndividual * m_individual;
    
	/*
	 * The constructor.
	 */
	Kendall_Model(int problem_size, int sel_size);
	
	/*
	 * The destructor. It frees the memory allocated at the construction of the kendall model.
	 */
	virtual ~Kendall_Model();
	
    /*
     * Builds the Mallows model for the Kendall distance with the given CR and theta parameters.
     */
    bool Learn(CIndividual * individual, double theta);
    
    /*
     * Given the consensus ranking, it samples a new individual based on the stirling numbers, with big numbers.
     */
    int Fast_Sampling(std::discrete_distribution<> * distance_sampler,std::mt19937 * gen, mpz_t ** stirling_matrix, CPopulation * population, int num_samples, int * index_at_population, PFSP * problem);
    
    /*
     * Given the consensus ranking, it samples a new individuals.
     */
    int Sampling(std::discrete_distribution<> *distance_sampler,std::mt19937 * gen, mpz_t ** count_matrix, CPopulation * population, int num_samples, int * index_at_population, PFSP * problem);
    
private:

    
    /*
     * The auxiliary vector for sampling solutions.
     */
    int * m_sampling_permutation;
    
    /*
     * Auxiliary data structures for sampling stage.
     */
    int * m_aux;
    int * aux_n;
    int * m_Vjs;
    double* m_acum;
    /*
     * Generates a permutation from a v vector.
     */
    void GeneratePermuFromV(int*v,int*permu);
    
    /*
     * Generates a permutation to a given distance from the identity.
     */
    void random_permu_at_dist_d( int dist, int*sigma, mpz_t ** count_matrix );
};

#endif
