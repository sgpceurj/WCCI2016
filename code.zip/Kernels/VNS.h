//
//  VNS.h
//  Kernels
//
//  Created by Josu Ceberio Uribe on 19/06/15.
//  Copyright (c) 2015 University of the Basque Country. All rights reserved.
//

#ifndef __Kernels__VNS__
#define __Kernels__VNS__

#include <stdio.h>

#include <stdio.h>
#include "PFSP.h"
#include "Individual.h"
#include "Population.h"
#include "Cayley.h"
#include "Tools.h"
#include <list>
#include <gmp.h>
#include <random>
using namespace std;

class VNS
{
    
public:
    
    /*
     * Problem
     */
    PFSP * m_problem;
    
    /*
     * Problem size
     */
    int m_problem_size;
    
    /*
     * Maximum number of evaluations permitted in the execution.
     */
    long int m_max_evaluations;
    
    /*
     * The number of evaluations performed at the moment.
     */
    long int m_evaluations;
    
    /*
     * The number of the evaluations performed to achieve the best solution so far.
     */
    long int m_convergence_evaluations;
    
    /*
     * The best solution found so far.
     */
    CIndividual * m_best;
    
    /*
     * Auxiliary vector.
     */
    int * m_aux;
    
    int * m_insert_best;
    int * m_insert_perm_aux;
    
    /*
     * The constructor.
     */
    VNS(PFSP * problem, int problem_size, long int max_evaluations);
    
    /*
     * The destructor.
     */
    virtual ~VNS();
    
    /*
     * Running function
     */
    double Run(CIndividual * inter, int shake_power, int trials);

    double Run_PopulationBased(CPopulation * population, int first_individuals,int shake_power,int trials);
    /*
     * Returns the number of performed evaluations.
     */
    long int GetPerformedEvaluations();
    
    /*
     * Returns the fitness of the best solution obtained.
     */
    double GetBestSolutionFitness();
    
    /*
     * Returns the best solution obtained.
     */
    CIndividual * GetBestSolution();

    /*
     * It applies random shake_power times a perturbation over the given individual.
     */
    void Shake_Swap(CIndividual *  individual, int shake_power);
    
    /*
     * This method applies a greedy local search with the swap operator neighborhood with the given power.
     */
    bool LocalSearch_Greedy_Swap2(CIndividual *  individual);
    
    /*
     * This method applies a greedy local search with the insert operator neighborhood with the given power.
     */
    bool LocalSearch_Greedy_Insert3(CIndividual *  individual);
    
    
    private:
    /*
     * Calculates the Hamming distance between 2 permutations.
     */
    int HammingDistance(int* permutationA, int*permutationB, int problem_size)
    {
        int dist=0;
        for(int i=0; i<problem_size; i++){
            dist+=(permutationA[i]!=permutationB[i]);
        }
        return dist;
    }
};
#endif /* defined(__Kernels__VNS__) */
